#include <stdio.h>
#include <string.h>

int down(char *num,int expon,int now);
int up(char *num,int expon,int now);
int stay(char *num,int expon,int now);
int zero_zero(char *num,int expon,int now);
